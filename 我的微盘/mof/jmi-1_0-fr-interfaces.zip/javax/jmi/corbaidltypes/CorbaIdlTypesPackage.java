package javax.jmi.corbaidltypes;

import javax.jmi.reflect.*;

public interface CorbaIdlTypesPackage extends RefPackage {
}
