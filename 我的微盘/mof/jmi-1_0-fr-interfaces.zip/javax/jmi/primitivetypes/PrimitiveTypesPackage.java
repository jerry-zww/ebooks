package javax.jmi.primitivetypes;

import javax.jmi.reflect.*;

public interface PrimitiveTypesPackage extends RefPackage {
}
