package javax.jmi.model;

import javax.jmi.reflect.*;

public interface BehavioralFeature extends Feature, Namespace {
}
