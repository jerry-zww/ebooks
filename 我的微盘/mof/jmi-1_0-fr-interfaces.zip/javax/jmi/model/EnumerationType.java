package javax.jmi.model;

import javax.jmi.reflect.*;

public interface EnumerationType extends DataType {
    public java.util.List getLabels();
}
