package javax.jmi.model;

import javax.jmi.reflect.*;

public interface FeatureClass extends RefClass {
}
