package javax.jmi.model;

import javax.jmi.reflect.*;

public interface MofException extends BehavioralFeature {
}
