package javax.jmi.model;

import javax.jmi.reflect.*;

public interface EvaluationKind extends RefEnum {
}
