package javax.jmi.model;

import javax.jmi.reflect.*;

public interface VisibilityKind extends RefEnum {
}
